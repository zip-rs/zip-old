use std::fs;
use std::io::{self, Cursor, Read, Seek, Write};
use std::path::{Path, PathBuf};

use getrandom::getrandom;
use tempfile;
use zip::{read::Handle, result::ZipResult, write::FileOptions, ZipArchive, ZipWriter};

fn generate_random_archive(
    num_entries: usize,
    entry_size: usize,
    options: FileOptions,
) -> ZipResult<Vec<u8>> {
    let buf = Cursor::new(Vec::new());
    let mut zip = ZipWriter::new(buf);

    let mut bytes = vec![0u8; entry_size];
    for i in 0..num_entries {
        let name = format!("random{}.dat", i);
        zip.start_file(name, options)?;
        getrandom(&mut bytes).unwrap();
        zip.write_all(&bytes)?;
    }

    let buf = zip.finish()?.into_inner();

    Ok(buf)
}

fn perform_pipelined<'a, P: AsRef<Path>>(src: ZipArchive<Handle<'a>>, target: P) -> ZipResult<()> {
    src.extract_pipelined(target)
}

fn perform_sync<R: Read + Seek, W: Write + Seek, P: AsRef<Path>>(
    mut src: ZipArchive<R>,
    target: P,
) -> ZipResult<()> {
    src.extract(target)
}

const NUM_ENTRIES: usize = 100;
const ENTRY_SIZE: usize = 100;

fn extract_pipelined() -> ZipResult<PathBuf> {
    let options = FileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    let src = generate_random_archive(NUM_ENTRIES, ENTRY_SIZE, options).unwrap();

    let td = tempfile::TempDir::new()?;
    io::copy(
        &mut Cursor::new(&src),
        &mut fs::File::create(td.path().join("out.zip"))?,
    )?;

    let src = ZipArchive::new(Handle::mem(&src)).unwrap();

    perform_pipelined(src, &td)?;
    Ok(td.into_path())
}

fn extract_sync() -> ZipResult<PathBuf> {
    let options = FileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    let src = generate_random_archive(NUM_ENTRIES, ENTRY_SIZE, options).unwrap();

    let td = tempfile::TempDir::new()?;
    perform_sync::<Cursor<Vec<u8>>, Cursor<Vec<u8>>, _>(ZipArchive::new(Cursor::new(src))?, &td)?;
    Ok(td.into_path())
}

fn main() -> ZipResult<()> {
    let ret = extract_pipelined()?;
    dbg!(ret);
    Ok(())
}
